package com.jlt.pojo;

public class Current extends Account {

	private double overdraftBalance;

	public Current() {
		System.out.println("Default Constructor of Current");
	}

	public Current(String name, double balance, double overdraftBalance) {
		super(name, balance);
		this.overdraftBalance = overdraftBalance;
	}

	@Override
	public boolean withdraw(double amount) {
		if(super.getBalance()>=amount) {
			double balance=super.getBalance();
			super.setBalance(balance-amount);
			return true;
		}
		else if(super.getBalance()>0 && super.getBalance()+overdraftBalance>=amount) {
			double balance=super.getBalance();
			amount=amount-balance;
			super.setBalance(0);
			overdraftBalance=overdraftBalance-amount;
			return true;
		}
		if(overdraftBalance>=amount) {
			overdraftBalance=overdraftBalance-amount;
			return true;
		}
		return false;
	}

	@Override
	public boolean deposit(double amount) {
		double pendingAmount;
		if(overdraftBalance<50000) {
			if(overdraftBalance+amount>=50000) {
				pendingAmount=amount-(50000-overdraftBalance);
				overdraftBalance=50000;
				double balance=super.getBalance();
				super.setBalance(balance+pendingAmount);
				return true;
			}
			else {
				overdraftBalance=overdraftBalance+amount;
			}
		}
		else if(overdraftBalance==50000) {
			double balance=super.getBalance();
			super.setBalance(balance+amount);
			return true;
		}
		return false;
	}

	public double getOverdraftBalance() {
		return overdraftBalance;
	}

	public void setOverdraftBalance(double overdraftBalance) {
		this.overdraftBalance = overdraftBalance;
	}
	
	@Override
	public String toString() {
		return "Current [overdraftBalance=" + overdraftBalance + ", toString()=" + super.toString() + "]";
	}

}
